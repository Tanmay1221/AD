package com.training.dao;

public interface LoginDao {
	boolean validateUser(String uname,String upass);
}
