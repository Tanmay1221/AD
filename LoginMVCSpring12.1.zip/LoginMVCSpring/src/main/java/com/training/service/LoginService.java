package com.training.service;

public interface LoginService {
	boolean validateUser(String uname,String upass);

}
