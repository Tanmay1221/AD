package com.iet.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.iet.model.User;
import com.iet.service.CityService;
import com.iet.service.UserService;
@Controller
public class WelcomeController {
	@Autowired
	CityService cityService;
	@Autowired UserService userService;
	@RequestMapping("/")
	public String getIndex() {
		return "index";
		
	}
	@RequestMapping("/signup")
	public String getSignup(Model model) {
		model.addAttribute("command", new User());
		List<String> list=cityService.getCity();
		model.addAttribute("cityList", list);
		return "regis";
	}
	@RequestMapping(value="/signup",method = RequestMethod.POST)
	public String postSignup(Model model,@ModelAttribute("command") @Valid User user,BindingResult result) {
		if(result.hasErrors()) {
			return "regis";
		}
		user=userService.addUser(user);
		if(user==null) {
			model.addAttribute("msgErr", "Error in registration...");
		}else {
			model.addAttribute("command", new User());
			List<String> list=cityService.getCity();
			model.addAttribute("cityList", list);
			model.addAttribute("msg", "user registration done...");
		}
			
		return "regis";
	}
	@RequestMapping("/list")
	public String getList(Model model) {
		List<User> list=userService.getUsers();
		model.addAttribute("list", list);
		return "listUser";
	}
}
