package com.iet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iet.DAO.UserDAO;
import com.iet.model.User;
@Service
public class UserServiceImpl implements UserService {
	@Autowired UserDAO userDAO;
	public User addUser(User user) {
		return userDAO.save(user);
	}
	public List<User> getUsers() {
		return userDAO.users();
	}

}
