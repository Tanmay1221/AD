package com.iet.service;

import java.util.List;

public interface CityService {

	List<String> getCity();

}
