package com.iet.service;

import java.util.List;

import com.iet.model.User;

public interface UserService {

	User addUser(User user);

	List<User> getUsers();


}
