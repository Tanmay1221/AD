package com.iet.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class User implements Serializable{
	@Id
	private String uid;
	@NotEmpty(message = "Enter name")
	//@Pattern(regexp="[a-zA-Z]{2,20}",message = "User name can not allowed other than char,")
	private String uname;
	private String city;
	private String email;
	private String pass;

	public User() {
		super();
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public User(String uid, String uname, String email, String pass, String city) {
		super();
		this.uid = uid;
		this.uname = uname;
		this.email = email;
		this.pass = pass;
		this.city = city;
	}

	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", city=" + city + ", email=" + email + ", pass=" + pass + "]";
	}
	

}
