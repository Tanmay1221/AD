package com.iet.DAO;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.iet.model.User;
@Repository
public class UserDAOImpl implements UserDAO {
	@Autowired SessionFactory sessionFactory;
	public User save(User user) {
		try {
		Session session=sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		String userid= (String)session.save(user);
		user=session.get(User.class, userid);
		t.commit();
		session.close();
		return user;
		}catch (Exception e) {
			return null;
		}
	}
	public List<User> users() {
		Session s=sessionFactory.openSession();
		Transaction tr=s.beginTransaction();
		Query q=s.createQuery("from User");
		List<User> list=q.getResultList();
		tr.commit();
		s.close();
		return list;
	}

}
