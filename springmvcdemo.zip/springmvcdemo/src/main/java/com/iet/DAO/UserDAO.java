package com.iet.DAO;

import java.util.List;

import com.iet.model.User;

public interface UserDAO {

	User save(User user);

	List<User> users();

}
