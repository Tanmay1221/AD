package com.training.beans;

public class HelloWorld {
	public HelloWorld() {
		System.out.println("In HelloWorld default Constructor");
	}

	public String sayHello() {
		return "Hello World!";
	}
}
