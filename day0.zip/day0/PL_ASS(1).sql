/*
1.

drop procedure if exists pro2;
delimiter $
create procedure pro2()
begin

declare message varchar(50);
declare Date_written date;

set message := 'My First PL/SQL program';
set Date_written := curdate();

 insert into temp values (message,Date_written);
 select * from temp;
end $
delimiter ;




O/P :

mysql> source /home/iet/Mysql/PL_ASS.sql
Query OK, 0 rows affected (0.11 sec)

Query OK, 0 rows affected (0.07 sec)

mysql> call pro2();

+-------------------------+--------------+
| message                 | date_written |
+-------------------------+--------------+
| NULL                    | NULL         |
| My First PL/SQL program | 2019-10-12   |
| My First PL/SQL program | 2019-10-12   |
+-------------------------+--------------+
3 rows in set (0.07 sec)

Query OK, 0 rows affected (0.07 sec)

*/


drop procedure if exists pro2;
delimiter $
create procedure pro2(NUM1 int,NUM2 int)
begin
declare RESULT int;
set RESULT:= NUM1 / NUM2;
select RESULT;
end $
delimiter ;



